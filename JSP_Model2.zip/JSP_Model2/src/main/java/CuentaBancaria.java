import java.io.Serializable;
import java.util.Map;
import java.util.List;
import java.util.LinkedList;

public class CuentaBancaria implements Serializable{
    
    private Integer nroCuenta;
    private Integer saldo;
    private Integer activo;
    private List<CuentaBancaria> conjunto = new LinkedList<>();
    
    public CuentaBancaria(){
    }
    
    public CuentaBancaria(Integer nroCuenta, Integer saldo){
        this.nroCuenta = nroCuenta;
        this.saldo = saldo;        
    }
    
     public Integer getNroCuenta() {
        return nroCuenta;
    }

    public void setNroCuenta(Integer nroCuenta) {
        this.nroCuenta = nroCuenta;
    }
    
    public Integer getSaldo(){
        return saldo;
    }
    
    public void setSaldo(Integer saldo){
        this.saldo = saldo;
    }
    
    public static List<CuentaBancaria> getCuentas(){
    conjunto.add(new CuentaBancaria(00000001, 10000000));
    conjunto.add(new CuentaBancaria(00000002, 20000000));
    conjunto.add(new CuentaBancaria(00000003, 15000000));    
    return conjunto;
    }
    
    public void Transferir(CuentaBancaria A, CuentaBancaria B, Integer monto){
        A.saldo -= monto;//hacer control error
        B.saldo += monto;
    }
/*********************** Procesamientos y validaciones **********************/
    public void procesar(Map<String, String[]> parameterMap) {
        setNroCuenta(Integer.valueOf(parameterMap.get("nroCuenta")[0]));
        setSaldo(Integer.valueOf(parameterMap.get("saldo")[0]));
        //setSectores(parameterMap.get("sectores"));
    }/*
    public String getNumeroCuenta (Integer codigo){
        String nombres[] = {"00000001", "0000002", "0000003"};
        return nombres[codigo -1];
    }//1000000, 2000000, 1500000
    */
}