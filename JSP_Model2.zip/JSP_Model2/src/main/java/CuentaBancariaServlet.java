
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


@WebServlet({"/transferencia"})
public class CuentaBancariaServlet extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //List<CuentaBancaria>[] = new CuentaBancaria().Inicializar(req.getParameterValues(conjunto));
        
        List cuentas = CuentaBancaria.getCuentas();
        req.setAttribute("cuentas", cuentas);
    }
    
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CuentaBancaria cuenta1 = new CuentaBancaria().Inicializar(req.getParameterMap());
        req.setAttribute("contacto", cuenta);
        req.getRequestDispatcher("/WEB-INF/movimiento.jsp").forward(req, resp);
    }   
}